1.) The software in the zipped file (MASM112.zip) can be used freely under the protection of the Microsoft
    Visual Studio 2019 Community License (VS_Community_2019_ENU.1033.docx).
2.) The document entitled "Emphasis On B. 4. Licenses For Other Components. Microsoft Platforms." included in
    this folder is the assurance that you can freely use the software and will protect your free use of
    this software indefinitely or as long as the Microsoft Visual Studio 2019 Community License is not
    officially revoked by Microsoft Corporation.
3.) To freely use this software, you must agree and abide to the terms explained by the Microsoft Visual Studio
    2019 Community License.
4.) The software included in the distribution is a collection of individual software created by Microsoft.
5.) This distribution can be legally redistributed if it is hosted in a Microsoft owned code repository 
    (e.g. GitHub).
6.) Refer to the file License (VS_Community_2019_ENU.1033.docx) for more information.
7.) If you don't agree to the terms of the Microsoft Visual Studio 2019 Community License and don't believe
    that certain provisions in the License will protect you from prosecution by the law, don't unzip MASM112.zip.

Note: Some files from the bin64 folder are from a distribution made by Andrew Canafe. His distribution is of his
      own and the files that were acquired from his "MASM64 SDK" were created and still owned by Microsoft 
      Corporation thus they can be applied with the appropriate and new license. 
      The files are repackaged in this distribution under the Visual Studio 2019 Community License 
      with an Emphasis on "B. 4. Licenses For Other Components. Microsoft Platforms." to assure freedom of use.

      Files from the bin48 folder are from Microsoft Windows 2000/Me DDK.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~ House Of Guillermo [GIMO] ~~~~~~~~~~~~~~
~~ alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] ~~
~~~~~~~ w32.perrun remix productions 114 ~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~